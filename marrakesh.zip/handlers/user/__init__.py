from .menu import dp
from .cart import dp
from .catalog import dp
from .delivery_status import dp
from .sos import dp
from .reviews import dp
from .recrute import dp
from .referal import dp

__all__ = ['dp']
