from .add import dp
from .questions import dp
from .orders import dp
from .mail import dp
from .settings import dp
from .moderate_reviews import dp
from .work import dp

__all__ = ['dp']
