API Reference
=============

.. contents:: Contents
   :local:

.. autoclass:: github_webhook.Webhook
   :members:
